/**
 * 实现代码文件
 * 
 * @author XXX
 * @since 2016-3-4
 * @version V1.0
 */
package com.routesearch.route;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Stack;

public final class Route {
    static int start;
    static int end;
    static int v = 0;
    static int[][] Graph;

    public static String searchRoute(String graphContent, String condition) {
        Stack<Integer> vstack = new Stack<Integer>();
        ArrayList<path> result = new ArrayList<path>();
        // Deal with String graphContent

        String[] g = graphContent.split("\n");
        int[][] g_ = new int[g.length][4];
        for (int i = 0; i < g.length; i++) {
            int max;
            g_[i][0] = Integer.parseInt(g[i].split(",")[0]);
            g_[i][1] = Integer.parseInt(g[i].split(",")[1]);
            g_[i][2] = Integer.parseInt(g[i].split(",")[2]);
            g_[i][3] = Integer.parseInt(g[i].split(",")[3]);
            max = g_[i][1] >= g_[i][2] ? g_[i][1] : g_[i][2];
            if (max >= v) {
                v = max;
            }
        }
        v += 1;// Number of V = Max node number + 1
        Graph = new int[v][v];
        // Deal with String condition
        String[] r = condition.replace('\n', ',').split(",");
        start = Integer.parseInt(r[0]);
        end = Integer.parseInt(r[1]);
        r = r[2].split("\\|");
        int[] pass = new int[r.length];
        for (int i = 0; i < r.length; i++)
            pass[i] = Integer.parseInt(r[i]);

        // Handle Adj Matrix

        for (int i = 0; i < v; i++)
            for (int j = 0; j < v; j++)
                Graph[i][j] = Integer.MAX_VALUE;
        for (int h = 0; h < g_.length; h++) {
            int x = g_[h][1];// out
            int y = g_[h][2];// in
            int z = g_[h][3];// weight
            Graph[x][y] = z <= Graph[x][y] ? z : Graph[x][y];// Record the
                                                                // smallest
                                                                // distance
        }

        // Start to find path
        boolean stackstatus[] = new boolean[v];
        boolean deadpoint[] = new boolean[v];

        vstack.push(start);
        stackstatus[start] = true;
        int prev = 0;
        int curr = start;
        while (true) {
            stage2: while (curr != end) {

                if (prev > v - 1) {
                    prev = 0;
                    break stage2;
                }
                stage1: for (int x = prev; x < v; x++) {
                    if (Graph[curr][x] < Integer.MAX_VALUE && !stackstatus[x]) {
                        vstack.push(x);
                        stackstatus[x] = true;
                        curr = x;
                        break stage1;
                    }
                    if (x == v - 1) {
                        stackstatus[vstack.peek()] = false;
                        x = vstack.pop();
                        if (vstack.isEmpty()) {
                            break;
                        }
                        curr = vstack.peek();
                    }

                } // end of stage1

                prev = 0;// reset "prev" indicator
            } // end of stage2

            if (vstack.firstElement() != start) {
                break;
            }

            if (curr == end) {
                // Valid
                int count = 0;
                for (int i : vstack) {
                    for (int j : pass) {
                        if (j == i) {
                            count++;
                        }

                    }
                }

                if (count == pass.length) {

                    path temp = new path();
                    temp.interpoint.add(start);
                    for (int i = 1; i <= vstack.size() - 1; i += 1) {
                        temp.weighit += Graph[vstack.elementAt(i - 1)][vstack.elementAt(i)];
                        temp.interpoint.add(vstack.elementAt(i));

                    }
                    result.add(temp);

                }
            }
            if (vstack.size() == 2) {
                stackstatus[vstack.peek()] = false;
                prev = vstack.pop() + 1;
                curr = vstack.peek();

            } else {
                stackstatus[vstack.peek()] = false;
                int next = vstack.pop();
                if (vstack.empty()) {
                    break;

                }
                if (!hasNext(vstack.peek(), next + 1, stackstatus)) {
                    // top no next
                    stackstatus[vstack.peek()] = false;
                    prev = vstack.pop() + 1;
                    curr = vstack.peek();
                } else {
                    // top do has next
                    prev = vstack.peek() + 1;
                    curr = vstack.peek();

                }
            }

        } // end of big while

        result.sort(new Comparator<path>() {

            @Override
            public int compare(path o1, path o2) {
                return o1.weighit - o2.weighit;
            }

        });
        if(result.get(0)==null){
            return "NA";
        }else{
            result.get(0).setinterNumber(g_);
            return result.get(0).getinterNumber();
            
        }
        
    }

    public static boolean hasNext(int idx, int startpoint, boolean[] stackstatus) {

        for (int i = startpoint; i < v; i++) {
            if (Graph[idx][i] < Integer.MAX_VALUE && i != end && !stackstatus[i]) {
                return true;
            }

        }

        return false;
    }

}

class path {
    public int weighit;
    public ArrayList<Integer> internumber = new ArrayList<Integer>();
    public ArrayList<Integer> interpoint = new ArrayList<Integer>();

    public void setinterNumber(int g[][]) {
        for (int i = 1; i < interpoint.size(); i++) {
            int a = interpoint.get(i - 1);
            int b = interpoint.get(i);
            for (int j = 0; j < g.length; j++) {
                if (a == g[j][1] & b == g[j][2]) {
                    internumber.add(g[j][0]);
                }
            }

        }
    }

    public String getinterNumber(){
        if(this.internumber.size()==0){
            return "NA";
            
        }else{
            String ans = "";
            for(int i:internumber){
                ans+=i+"|";
            }
            
            return ans.substring(0,ans.length()-1);
        }
        
        
    }
}
